# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'b0e560b79b1c863ae7308e209d6db073e6db9e1ada20efe4152af7c0318ed9cba7d5290873d468f0353cecce654cc9291c3789febb4e9bd07ed4e913bdd4c2b1'